var nytg = nytg || {};

nytg.budget_array_data = [{
    "name": "Grain Inspection, Packers and Stockyards Administration",
    "positions": {
        "total": {
            "x": 1,
            "y": 1
        },
        "department": {
            "x": 1,
            "y": 1
        }
    },
    "id": 126,
    "change": 0.0526315789473684,
    "budget_2013": 40000,
    "department": "Agriculture",
    "discretion": "Discretionary"
},
{
    "name": "Food and Nutrition Service",
    "positions": {
        "total": {
            "x": 1,
            "y": 1
        },
        "department": {
            "x": 1,
            "y": 1
        }
    },
    "id": 366,
    "change": 0.0117737634731663,
    "budget_2013": 107762000,
    "department": "Agriculture",
    "discretion": "Mandatory"
},
{
    "name": "National Institute of Food and Agriculture",
    "positions": {
        "total": {
            "x": 1,
            "y": 1
        },
        "department": {
            "x": 1,
            "y": 1
        }
    },
    "id": 171,
    "change": 0.0332225913621262,
    "budget_2013": 1244000,
    "department": "Agriculture",
    "discretion": "Discretionary"
},
{
    "name": "Forest Service",
    "positions": {
        "total": {
            "x": 1,
            "y": 1
        },
        "department": {
            "x": 1,
            "y": 1
        }
    },
    "id": 120,
    "change": 0.0523003472222222,
    "budget_2013": 4849000,
    "department": "Agriculture",
    "discretion": "Discretionary"
},
{
    "name": "Farm Service Agency",
    "positions": {
        "total": {
            "x": 1,
            "y": 1
        },
        "department": {
            "x": 1,
            "y": 1
        }
    },
    "id": 95,
    "change": -0.076662908680947,
    "budget_2013": 1638000,
    "department": "Agriculture",
    "discretion": "Discretionary"
},
{
    "name": "Includes: Rural Electrification and Telephone Loans, Negative Subsidies",
    "positions": {
        "total": {
            "x": 1,
            "y": 1
        },
        "department": {
            "x": 1,
            "y": 1
        }
    },
    "id": 56,
    "change": 0.913669064748201,
    "budget_2013": -266000,
    "department": "Agriculture",
    "discretion": "Discretionary"
},
{
    "name": "Office of Civil Rights",
    "positions": {
        "total": {
            "x": 1,
            "y": 1
        },
        "department": {
            "x": 1,
            "y": 1
        }
    },
    "id": 195,
    "change": 2,
    "budget_2013": 63000,
    "department": "Agriculture",
    "discretion": "Discretionary"
}
];





nytg.category_data = [
{
    "label": "Health and Human Services",
    "total": 921605000,
    "short_label": "Health and Human Services"
},
{
    "label": "State",
    "total": 31608000,
    "short_label": "State"
},
{
    "label": "Judicial Branch",
    "total": 7502000,
    "short_label": "Judicial Branch"
},
{
    "label": "International Assistance Programs",
    "total": 37399000,
    "short_label": "International"
},
{
    "label": "Agriculture",
    "total": 154667000,
    "short_label": "Agriculture"
},
{
    "label": "Treasury",
    "total": 519490000,
    "short_label": "Treasury"
},
{
    "label": "Other Defense Civil Programs",
    "total": 57416000,
    "short_label": "Defense Civil Programs"
},
{
    "label": "Appalachian Regional Commission",
    "total": 64000,
    "short_label": "Appalachian Commission"
},
{
    "label": "Legislative Branch",
    "total": 4789000,
    "short_label": "Legislative Branch"
},
{
    "label": "Veterans Affairs",
    "total": 137381000,
    "short_label": "Veterans Affairs"
},
{
    "label": "Justice",
    "total": 30023000,
    "short_label": "Justice"
},
{
    "label": "Interior",
    "total": 11357000,
    "short_label": "Interior"
},
{
    "label": "Commerce",
    "total": 9239000,
    "short_label": "Commerce"
},
{
    "label": "Labor",
    "total": 88993000,
    "short_label": "Labor"
},
{
    "label": "Homeland Security",
    "total": 45109000,
    "short_label": "Homeland Security"
},
{
    "label": "Housing and Urban Development",
    "total": 44010000,
    "short_label": "Housing"
},
{
    "label": "Corps of Engineers--Civil Works",
    "total": 4668000,
    "short_label": "Corps of Engineers"
},
{
    "label": "Executive Office of the President",
    "total": 392000,
    "short_label": "Office of the President"
},
{
    "label": "Energy",
    "total": 32300000,
    "short_label": "Energy"
},
{
    "label": "Transportation",
    "total": 74280000,
    "short_label": "Transportation"
},
{
    "label": "Education",
    "total": 55685000,
    "short_label": "Education"
},
{
    "label": "Federal Deposit Insurance Corporation",
    "total": 1515000,
    "short_label": "F.D.I.C."
},
{
    "label": "District of Columbia",
    "total": 902000,
    "short_label": "District of Columbia"
},
{
    "label": "Environmental Protection Agency",
    "total": 8138000,
    "short_label": "E.P.A."
},
{
    "label": "Defense - Military",
    "total": 620259000,
    "short_label": "Defense"
},
{
    "label": "Institute of Museum and Library Services",
    "total": 231000,
    "short_label": "Museum and Library Services"
},
{
    "label": "National Aeronautics and Space Administration",
    "total": 17693000,
    "short_label": "NASA"
},
{
    "label": "National Archives and Records Administration",
    "total": 370000,
    "short_label": "National Archives"
},
{
    "label": "National Science Foundation",
    "total": 7470000,
    "short_label": "N.S.F."
},
{
    "label": "Nuclear Regulatory Commission",
    "total": 127000,
    "short_label": "Nuclear Regulation"
},
{
    "label": "Office of Personnel Management",
    "total": 94857000,
    "short_label": "Personnel Management"
},
{
    "label": "Postal Service",
    "total": 78000,
    "short_label": "Postal Service"
},
{
    "label": "Public Company Accounting Oversight Board",
    "total": 237000,
    "short_label": "Accounting Oversight"
},
{
    "label": "Railroad Retirement Board",
    "total": 7202000,
    "short_label": "Railroad Retirement"
},
{
    "label": "Small Business Administration",
    "total": 1111000,
    "short_label": "Small Business"
},
{
    "label": "Social Security Administration",
    "total": 885315000,
    "short_label": "Social Security"
},
{
    "label": "Federal Communications Commission",
    "total": 9633000,
    "short_label": "F.C.C."
},
{
    "label": "Securities Investor Protection Corporation",
    "total": 259000,
    "short_label": "S.I.P.C."
},
{
    "label": "S123333333333333n",
    "total": 99959000,
    "short_label": "12312344444444"
},
{
    "label": "Other",
    "total": -512596000,
    "short_label": "Other"
}
];